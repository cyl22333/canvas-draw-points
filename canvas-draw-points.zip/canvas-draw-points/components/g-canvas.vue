<template>
	<scroll-view scroll-y scroll-x>
		<view class="canvas_container"
			:style="{width:`${ctxWidth}px`,height:`${ctxHeight}px`,backgroundImage:`url(${backImage})`,backgroundSize:'100% 100%'}">
			<!-- 遮罩 图形镂空高亮 -->
			<canvas class="mask" canvas-id="mask" :style="{width:`${ctxWidth}px`,height:`${ctxHeight}px`}"></canvas>
			<!-- 绘制图形容器 -->
			<canvas class="canvas" canvas-id="canvas" id="canvas" :style="{width:`${ctxWidth}px`,height:`${ctxHeight}px`}"
				 @touchstart="handleClick"></canvas>
		</view>
	</scroll-view>
</template>
<script>
  export default {
    name: 'canvas-draw-points'
  }
</script>
<script setup>
	import {
		onMounted,
		ref,
		toRaw,
		getCurrentInstance
	} from 'vue';
	const {proxy} =getCurrentInstance()
	const props=defineProps({
		backImage:String, //背景图 、地块图片
		points:Array, //选中的地块图形点位 [{图形1(x,y)}，{图形2（x,y）}]
		ratio:{
			type:Number,
			default:1 //默认1:1   2=2:1依此类推（注意是背景图和手机屏幕的展示分辨率比例）
		}
	})
	const ctxWidth = ref(0)
	const ctxHeight = ref(0)
	const ratioX = ref(0)
	const ratioY = ref(0)
	const ctx = uni.createCanvasContext('canvas', proxy)
	const {
		windowHeight,
		windowWidth,
		pixelRatio
	} = uni.getSystemInfoSync()

	onMounted(() => {
		initCanvas()
	})
	/**
	 * 	初始化canvas
	 */
	const initCanvas = () => {
		uni.getImageInfo({
			src: props.backImage,
			success(res) {
				if(props.ratio==1){
					ctxWidth.value = windowWidth
					ctxHeight.value = windowHeight
				}else{
					ctxWidth.value = res.width/props.ratio
					ctxHeight.value = res.height/props.ratio
				}
				ratioX.value = res.width / ctxWidth.value
				ratioY.value = res.height / ctxHeight.value
			},
			fail(err) {
				console.error(err)
			}
		})
	}
	const maskCtx = uni.createCanvasContext('mask', proxy)
	/**
	 * 点击坐标内区域
	 */
	const handleClick = (e) => {
		const touches = e.touches.length ? e.touches[0] : null
		const {
			x,
			y
		} = touches
		let ratioPoints=getRatioPoints(props.points) //如果是1:1铺满全屏需要计算xy,如果不是1:1就不用计算
		let shapeIndex=findMatchingGroup({x,y},ratioPoints) //查找当前点击区域是否是规划的图形区域
		if(shapeIndex>-1){
			renderMask(ratioPoints[shapeIndex]) //渲染选中组的图形
		}else{
			 maskCtx.clearRect(0, 0, ctxWidth.value, ctxHeight.value);
			 maskCtx.draw()
			
		}
	}
	// 根据设置的页面展示比例计算x,y
	const getRatioPoints=(points)=>{
			if(props.ratio==1){
				return	points.map((item,index)=>{
						return  points[index].map((childItem,childIndex)=>{
							const [x, y] = [childItem.x / ratioX.value, childItem.y / ratioY.value]
							return{
								x,
								y
							}
						})
					})
			}
			return points
	}
	// 返回选中范围位于点位数组的下标
	const findMatchingGroup=(target, pointArray)=>{
	  return  pointArray.findIndex(group => isPointInShape(target.x,target.y,group));
	} 
	/**
	 * 渲染透明层
	 */
	const renderMask = (newPoints) => {
		// 1. 绘制整个画布的遮罩层 (例如，半透明的黑色)
		maskCtx.fillStyle = 'rgba(0, 0, 0, 0.3)';
		maskCtx.fillRect(0, 0, ctxWidth.value, ctxHeight.value);
		maskCtx.save()
		// 2. 绘制透明的画框区域
		maskCtx.globalCompositeOperation = 'destination-out';
		maskCtx.beginPath();
		newPoints.forEach((point, index) => {
			
			if (index === 0) {
				maskCtx.moveTo(point.x, point.y);
			} else {
				maskCtx.lineTo(point.x, point.y);
			}
		});
		maskCtx.closePath();
		maskCtx.fillStyle = 'rgba(0, 0, 0, 1)'; // 完全不透明，用于擦除
		maskCtx.fill()
		maskCtx.restore()
		maskCtx.draw();
	}
	/**
	 * 判断坐标点是否在绘制图形区域内
	 */
	const isPointInShape=(x, y, shape)=>{
	  let inside = false
	  for (let i = 0, j = shape.length - 1; i < shape.length; j = i++) {
	    if (((shape[i].y > y) != (shape[j].y > y)) &&
	        (x < (shape[j].x - shape[i].x) * (y - shape[i].y) / (shape[j].y - shape[i].y) + shape[i].x)) {
	      inside = !inside
	    }
	  }
	  return inside
	}
	/**
	 * 获取区域的重心/质心
	 * @param {Object} points
	 */
	function getBaryCenter(points) {
		if (!Array.isArray(points) || points.length < 3) {
			console.error("多边形坐标集合不能少于3个");
			return;
		}
		const result = {
			x: 0,
			y: 0
		};
		let area = 0;
		for (let i = 1; i <= points.length; i++) {
			const curX = points[i % points.length].x;
			const curY = points[i % points.length].y;
			const nextX = points[i - 1].x;
			const nextY = points[i - 1].y;
			const temp = (curX * nextY - curY * nextX) / 2;
			area += temp;
			result.x += (temp * (curX + nextX)) / 3;
			result.y += (temp * (curY + nextY)) / 3;
		}
		result.x /= area;
		result.y /= area;
		return result;
	}
	
</script>

<style lang="scss">
	.canvas_container {
		position: relative;
		.canvas {
			position: absolute;
			z-index: 2;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			width: 100%;
			height: 100%;
		}
	}
</style>